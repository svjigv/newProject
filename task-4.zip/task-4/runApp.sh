#!/bin/bash
java -jar HotelApp.jar